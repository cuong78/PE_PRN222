﻿using System.ComponentModel.DataAnnotations;

namespace GoldBracelet_BO
{
    public partial class GoldBracelet
    {
        public int BraceletId { get; set; }
        [Required(ErrorMessage = "Not Null")]
        [MinLength(7, ErrorMessage = "Bracelet name must be at least 7 characters.")]
        [RegularExpression(@"^(?=.*[A-Z0-9])[A-Za-z0-9@#$&()]+$", ErrorMessage = "Each word must begin with a capital letter or a digit, and only special characters @, #)")]
        public string BraceletName { get; set; } = null!;
        [Required(ErrorMessage = "Not Null")]
        public string? BraceletDescription { get; set; }
        [Required(ErrorMessage = "Not Null")]
        public decimal? Price { get; set; }
        [Required(ErrorMessage = "Not Null")]
        [Range(1990, 2023, ErrorMessage = "Production year must be between 1990 and 2023")]
        public int? ProductionYear { get; set; }
        [Required(ErrorMessage = "Not Null")]
        public DateTime? CreatedDate { get; set; }
        [Required(ErrorMessage = "Not Null")]
        public string? TypeId { get; set; }

        public virtual ProductType? Type { get; set; }
    }
}
