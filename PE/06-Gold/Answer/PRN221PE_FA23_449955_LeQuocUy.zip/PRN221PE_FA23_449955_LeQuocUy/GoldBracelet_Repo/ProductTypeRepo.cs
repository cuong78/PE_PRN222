﻿using GoldBracelet_BO;
using GoldBracelet_DAO;

namespace GoldBracelet_Repo
{
    public class ProductTypeRepo : IProductTypeRepo
    {
        public async Task<List<ProductType>> GetList()
        {
            return await GoldBraceletDAO.Instance.GetProductTypes();
        }
    }
}
