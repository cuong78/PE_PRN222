﻿using GoldBracelet_BO;
using GoldBracelet_Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GoldBracelet_SE172445_LeQuocUy.Pages.GoldBraceletPage
{
    public class DeleteModel : PageModel
    {
        private readonly IGoldBraceletRepo _goldBraceletRepo;

        public DeleteModel(IGoldBraceletRepo goldBraceletRepo)
        {
            _goldBraceletRepo = goldBraceletRepo;
        }

        [BindProperty]
        public GoldBracelet GoldBracelet { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var goldbracelet = await _goldBraceletRepo.GetById(id.GetValueOrDefault());

            if (goldbracelet == null)
            {
                return NotFound();
            }
            else
            {
                GoldBracelet = goldbracelet;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            await _goldBraceletRepo.Delete(id.GetValueOrDefault());
            TempData["Message"] = "Delete successful!";

            return RedirectToPage("./Index");
        }
    }
}
