﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace GoldBracelet_BO
{
    public partial class GoldBracelet2023DBContext : DbContext
    {
        public GoldBracelet2023DBContext()
        {
        }

        public GoldBracelet2023DBContext(DbContextOptions<GoldBracelet2023DBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Account> Accounts { get; set; } = null!;
        public virtual DbSet<GoldBracelet> GoldBracelets { get; set; } = null!;
        public virtual DbSet<ProductType> ProductTypes { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(GetConnectionString());
            }
        }

        private string GetConnectionString()
        {
            IConfiguration configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", true, true).Build();
            return configuration["ConnectionStrings:DefaultConnectionString"];
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>(entity =>
            {
                entity.ToTable("Account");

                entity.HasIndex(e => e.EmailAddress, "UQ__Account__49A1474074DB5423")
                    .IsUnique();

                entity.Property(e => e.AccountId)
                    .ValueGeneratedNever()
                    .HasColumnName("AccountID");

                entity.Property(e => e.AccountPassword).HasMaxLength(40);

                entity.Property(e => e.EmailAddress).HasMaxLength(60);

                entity.Property(e => e.FullName).HasMaxLength(60);
            });

            modelBuilder.Entity<GoldBracelet>(entity =>
            {
                entity.HasKey(e => e.BraceletId)
                    .HasName("PK__GoldBrac__CC2AE62FA6476B60");

                entity.ToTable("GoldBracelet");

                entity.Property(e => e.BraceletId).ValueGeneratedNever();

                entity.Property(e => e.BraceletDescription).HasMaxLength(250);

                entity.Property(e => e.BraceletName).HasMaxLength(100);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Price).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.TypeId).HasMaxLength(30);

                entity.HasOne(d => d.Type)
                    .WithMany(p => p.GoldBracelets)
                    .HasForeignKey(d => d.TypeId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK__GoldBrace__TypeI__3C69FB99");
            });

            modelBuilder.Entity<ProductType>(entity =>
            {
                entity.HasKey(e => e.TypeId)
                    .HasName("PK__ProductT__516F03B5C97341C6");

                entity.ToTable("ProductType");

                entity.Property(e => e.TypeId).HasMaxLength(30);

                entity.Property(e => e.TypeDescription).HasMaxLength(250);

                entity.Property(e => e.TypeName).HasMaxLength(100);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
