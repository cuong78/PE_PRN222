﻿using GoldBracelet_BO;
using GoldBracelet_Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GoldBracelet_SE172445_LeQuocUy.Pages.GoldBraceletPage
{

    public class IndexModel : PageModel
    {
        private readonly IGoldBraceletRepo _goldBraceletRepo;

        public IndexModel(IGoldBraceletRepo goldBraceletRepo)
        {
            _goldBraceletRepo = goldBraceletRepo;
        }

        public IList<GoldBracelet> GoldBracelet { get; set; } = default!;

        //search
        [BindProperty(SupportsGet = true)]
        public string searchTerm { get; set; }

        //paging
        public int PageIndex { get; set; } = 1;

        public int TotalPages { get; set; }
        public int PageSize { get; set; } = 2;

        public async Task OnGetAsync(int pageIndex = 1)
        {
            var result = await _goldBraceletRepo.GetList(searchTerm, pageIndex, 4);

            GoldBracelet = result.GoldBracelets;
            PageIndex = result.PageIndex;
            TotalPages = result.TotalPages;
        }




    }
}
