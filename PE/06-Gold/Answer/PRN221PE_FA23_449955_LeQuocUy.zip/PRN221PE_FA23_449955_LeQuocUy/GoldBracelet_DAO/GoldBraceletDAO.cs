﻿using GoldBracelet_BO;
using Microsoft.EntityFrameworkCore;

namespace GoldBracelet_DAO
{
    public class GoldBraceletDAO
    {

        private readonly GoldBracelet2023DBContext _context;
        private static GoldBraceletDAO instance = null;

        private GoldBraceletDAO()
        {
            _context = new GoldBracelet2023DBContext();
        }

        public static GoldBraceletDAO Instance
        {
            get
            {
                if (instance == null)
                {
                    return new GoldBraceletDAO();
                }
                return instance;
            }
        }

        public async Task<List<GoldBracelet>> GetListGoldBracelets()
        {
            return await _context.GoldBracelets.Include(x => x.Type).ToListAsync();
        }

        public class GoldBraceletsResponse
        {
            public List<GoldBracelet> GoldBracelets { get; set; }
            public int TotalPages { get; set; }
            public int PageIndex { get; set; }
        }

        public async Task<GoldBraceletsResponse> GetList(string searchTerm, int pageIndex, int pageSize)
        {
            var query = _context.GoldBracelets.Include(x => x.Type).AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    var tempId = int.Parse(searchTerm);
                    query = query.Where(x => x.ProductionYear == tempId);

                }
                catch (Exception e)
                {
                    query = query.Where(x => x.BraceletName.ToLower().Contains(searchTerm.ToLower()));
                }
            }

            int count = await query.CountAsync(); //11
            int totalPages = (int)Math.Ceiling(count / (double)pageSize); //3

            query = query.Skip((pageIndex - 1) * pageSize).Take(pageSize);

            return new GoldBraceletsResponse
            {
                GoldBracelets = await query.OrderBy(x => x.CreatedDate).ToListAsync(),
                TotalPages = totalPages,
                PageIndex = pageIndex
            };
        }

        public async Task<GoldBracelet> GetGoldBraceletsById(int id)
        {
            return await _context.GoldBracelets.Include(x => x.Type).FirstOrDefaultAsync(m => m.BraceletId == id);
        }

        public async Task AddGoldBracelet(GoldBracelet goldBracelet)
        {
            try
            {
                var isExisting = await GetGoldBraceletsById(goldBracelet.BraceletId);
                if (isExisting != null)
                {
                    throw new Exception("It is already exists");
                }
                _context.GoldBracelets.Add(goldBracelet);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task UpdateGoldBracelet(GoldBracelet goldBracelet)
        {
            try
            {
                var isExist = await GetGoldBraceletsById(goldBracelet.BraceletId);
                if (isExist == null)
                {
                    throw new Exception("Does not exist");
                }

                isExist.BraceletName = goldBracelet.BraceletName;
                isExist.BraceletDescription = goldBracelet.BraceletDescription;
                isExist.Price = goldBracelet.Price;
                isExist.ProductionYear = goldBracelet.ProductionYear;
                isExist.CreatedDate = goldBracelet.CreatedDate;
                isExist.TypeId = goldBracelet.TypeId;

                var type = await _context.ProductTypes.FirstOrDefaultAsync(s => s.TypeId == goldBracelet.TypeId);
                if (type == null)
                {
                    throw new Exception("type does not exist");
                }
                isExist.Type = type;

                _context.GoldBracelets.Update(isExist);
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task DeleteGoldBracelet(int id)
        {
            try
            {
                var existArt = _context.GoldBracelets.FirstOrDefault(m => m.BraceletId == id);
                if (existArt == null)
                {
                    throw new Exception("GoldBracelet not found");
                }
                _context.GoldBracelets.Remove(existArt);
                await _context.SaveChangesAsync();

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task<List<ProductType>> GetProductTypes()
        {
            return await _context.ProductTypes.ToListAsync();
        }


    }
}
