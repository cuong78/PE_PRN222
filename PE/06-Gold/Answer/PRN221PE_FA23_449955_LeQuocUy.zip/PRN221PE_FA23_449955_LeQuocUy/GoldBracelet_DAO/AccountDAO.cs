﻿using GoldBracelet_BO;
using Microsoft.EntityFrameworkCore;

namespace GoldBracelet_DAO
{
    public class AccountDAO
    {

        private readonly GoldBracelet2023DBContext _context;
        private static AccountDAO instance = null;

        private AccountDAO()
        {
            _context = new GoldBracelet2023DBContext();
        }

        public static AccountDAO Instance
        {
            get
            {
                if (instance == null)
                {
                    return new AccountDAO();
                }
                return instance;
            }
        }

        public async Task<Account> Login(string email, string password)
        {
            return await _context.Accounts.FirstOrDefaultAsync(acc => acc.EmailAddress == email && acc.AccountPassword == password);
        }

    }
}
