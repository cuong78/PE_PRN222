﻿using GoldBracelet_BO;

namespace GoldBracelet_Repo
{
    public interface IAccountRepo
    {
        Task<Account> Login(string email, string password);
    }
}