﻿using GoldBracelet_BO;
using GoldBracelet_Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GoldBracelet_SE172445_LeQuocUy.Pages.GoldBraceletPage
{
    public class CreateModel : PageModel
    {
        private readonly IGoldBraceletRepo _goldBraceletRepo;
        private readonly IProductTypeRepo _productTypeRepo;

        public CreateModel(IGoldBraceletRepo goldBraceletRepo, IProductTypeRepo productTypeRepo)
        {
            _goldBraceletRepo = goldBraceletRepo;
            _productTypeRepo = productTypeRepo;
        }

        public async Task<IActionResult> OnGet()
        {
            ViewData["TypeId"] = new SelectList(await _productTypeRepo.GetList(), "TypeId", "TypeName");
            GoldBracelet = new GoldBracelet();
            GoldBracelet.CreatedDate = DateTime.Now;
            return Page();
        }

        [BindProperty]
        public GoldBracelet GoldBracelet { get; set; } = default!;


        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            try
            {
                await _goldBraceletRepo.Add(GoldBracelet);
                TempData["Message"] = "Add successful!";
                return RedirectToPage("./Index");
            }
            catch (Exception e)
            {
                TempData["ErrorMessage"] = e.Message;
                return RedirectToPage("/Error");
            }
        }
    }
}
