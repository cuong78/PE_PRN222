﻿using GoldBracelet_BO;
using GoldBracelet_DAO;
using static GoldBracelet_DAO.GoldBraceletDAO;

namespace GoldBracelet_Repo
{
    public class GoldBraceletRepo : IGoldBraceletRepo
    {
        public async Task<GoldBraceletsResponse> GetList(string searchTerm, int pageIndex, int pageSize)
        {
            return await GoldBraceletDAO.Instance.GetList(searchTerm, pageIndex, pageSize);
        }
        public async Task<GoldBracelet> GetById(int id)
        {
            return await GoldBraceletDAO.Instance.GetGoldBraceletsById(id);
        }
        public async Task Add(GoldBracelet goldBracelet)
        {
            await GoldBraceletDAO.Instance.AddGoldBracelet(goldBracelet);
        }
        public async Task Update(GoldBracelet goldBracelet)
        {
            await GoldBraceletDAO.Instance.UpdateGoldBracelet(goldBracelet);
        }
        public async Task Delete(int id)
        {
            await GoldBraceletDAO.Instance.DeleteGoldBracelet(id);
        }
    }
}
