﻿using GoldBracelet_BO;
using GoldBracelet_Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GoldBracelet_SE172445_LeQuocUy.Pages.GoldBraceletPage
{
    public class EditModel : PageModel
    {
        private readonly IGoldBraceletRepo _goldBraceletRepo;
        private readonly IProductTypeRepo _productTypeRepo;

        public EditModel(IGoldBraceletRepo goldBraceletRepo, IProductTypeRepo productTypeRepo)
        {
            _goldBraceletRepo = goldBraceletRepo;
            _productTypeRepo = productTypeRepo;
        }

        [BindProperty]
        public GoldBracelet GoldBracelet { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var goldbracelet = await _goldBraceletRepo.GetById(id.GetValueOrDefault());
            if (goldbracelet == null)
            {
                return NotFound();
            }
            GoldBracelet = goldbracelet;
            ViewData["TypeId"] = new SelectList(await _productTypeRepo.GetList(), "TypeId", "TypeName");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            try
            {
                await _goldBraceletRepo.Update(GoldBracelet);
                TempData["Message"] = "Update successful!";
                return RedirectToPage("./Index");
            }
            catch (Exception e)
            {
                TempData["ErrorMessage"] = e.Message;
                return RedirectToPage("/Error");
            }

        }

    }
}
