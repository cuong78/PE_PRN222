﻿using GoldBracelet_BO;

namespace GoldBracelet_Repo
{
    public interface IProductTypeRepo
    {
        Task<List<ProductType>> GetList();
    }
}