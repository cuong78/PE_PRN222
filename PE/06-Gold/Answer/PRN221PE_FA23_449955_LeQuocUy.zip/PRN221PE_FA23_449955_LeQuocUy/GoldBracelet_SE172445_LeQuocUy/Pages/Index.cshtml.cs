﻿using GoldBracelet_Repo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GoldBracelet_SE172445_LeQuocUy.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IAccountRepo _accountRepo;

        public IndexModel(IAccountRepo accountRepo)
        {
            _accountRepo = accountRepo;
        }

        [BindProperty]
        public string email { get; set; }

        [BindProperty]
        public string password { get; set; }


        public void OnGet()
        {

        }

        public async Task<IActionResult> OnPostAsync()
        {

            try
            {
                var account = await _accountRepo.Login(email, password);
                if (account != null && (account.AccountRole == 1 || account.AccountRole == 2))
                {
                    TempData["Message"] = "Login Success";
                    Console.WriteLine("Login Success");

                    //set session
                    HttpContext.Session.SetString("Email", email);
                    HttpContext.Session.SetInt32("RoleId", account.AccountRole ?? default(int));

                    return RedirectToPage("/GoldBraceletPage/Index");
                }
                else
                {
                    TempData["Message"] = "You do not have permission to do this function";
                    return Page();
                }
            }
            catch (Exception ex)
            {
                TempData["Message"] = ex.Message;
                return Page();
            }
        }
    }
}
