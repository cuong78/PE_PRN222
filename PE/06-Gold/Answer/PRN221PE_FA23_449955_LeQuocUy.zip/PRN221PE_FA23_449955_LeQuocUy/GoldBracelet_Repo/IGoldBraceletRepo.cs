﻿using GoldBracelet_BO;
using static GoldBracelet_DAO.GoldBraceletDAO;

namespace GoldBracelet_Repo
{
    public interface IGoldBraceletRepo
    {
        Task Add(GoldBracelet goldBracelet);
        Task Delete(int id);
        Task<GoldBracelet> GetById(int id);
        Task<GoldBraceletsResponse> GetList(string searchTerm, int pageIndex, int pageSize);
        Task Update(GoldBracelet goldBracelet);

    }
}