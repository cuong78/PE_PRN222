﻿using GoldBracelet_BO;
using GoldBracelet_DAO;

namespace GoldBracelet_Repo
{
    public class AccountRepo : IAccountRepo
    {
        public async Task<Account> Login(string email, string password)
        {
            return await AccountDAO.Instance.Login(email, password);
        }

    }
}
