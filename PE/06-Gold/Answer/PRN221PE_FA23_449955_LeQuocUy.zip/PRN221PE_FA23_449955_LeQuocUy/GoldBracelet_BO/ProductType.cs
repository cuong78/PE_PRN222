﻿using System;
using System.Collections.Generic;

namespace GoldBracelet_BO
{
    public partial class ProductType
    {
        public ProductType()
        {
            GoldBracelets = new HashSet<GoldBracelet>();
        }

        public string TypeId { get; set; } = null!;
        public string TypeName { get; set; } = null!;
        public string TypeDescription { get; set; } = null!;

        public virtual ICollection<GoldBracelet> GoldBracelets { get; set; }
    }
}
